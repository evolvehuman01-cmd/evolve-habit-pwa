// ─────────────────────────────────────────────────────────────────
// CoachDashboard.jsx
// Route: /coach
// Auth guard: password checked against VITE_COACH_SECRET env var
// ─────────────────────────────────────────────────────────────────
import { useState, useEffect, useCallback } from 'react';

const COACH_SECRET = import.meta.env.VITE_COACH_SECRET;  // shared secret
const DATA_SCRIPT  = import.meta.env.VITE_DATA_SCRIPT_URL;

// ── Utility ──────────────────────────────────────────────────────
function scriptUrl(params) {
  const qs = new URLSearchParams({ ...params, secret: COACH_SECRET }).toString();
  return `${DATA_SCRIPT}?${qs}`;
}

async function apiFetch(params) {
  const res = await fetch(scriptUrl(params));
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data;
}

async function apiPost(body) {
  // no-cors required for Apps Script — response is opaque but write succeeds
  await fetch(DATA_SCRIPT, {
    method: 'POST',
    mode: 'no-cors',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...body, secret: COACH_SECRET })
  });
  return { success: true };
}

// ─────────────────────────────────────────────────────────────────
// MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────
export default function CoachDashboard() {

  const [authed, setAuthed] = useState(false);
  if (!authed) return <PasswordGate onSuccess={() => setAuthed(true)} />;
  return <DashboardShell />;
}

// ─────────────────────────────────────────────────────────────────
// DASHBOARD SHELL — manages view state
// ─────────────────────────────────────────────────────────────────
function DashboardShell() {
  const [view, setView]           = useState('list');      // 'list' | 'detail' | 'targets'
  const [selectedClient, setSelected] = useState(null);
  const [clients, setClients]     = useState([]);
  const [loading, setLoading]     = useState(true);
  const [error, setError]         = useState(null);
  const [filterFlagged, setFilter]= useState(false);

  const loadClients = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const data = await apiFetch({ action: 'getActiveClients' });
      // Sort: flagged first, then by daysSinceLog desc
      const sorted = [...data.clients].sort((a, b) => {
        if (a.flagged && !b.flagged) return -1;
        if (!a.flagged && b.flagged) return 1;
        return b.daysSinceLog - a.daysSinceLog;
      });
      setClients(sorted);
    } catch(e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadClients(); }, [loadClients]);

  const openClient = (client) => { setSelected(client); setView('detail'); };
  const openTargets= (client) => { setSelected(client); setView('targets'); };
  const goBack     = ()       => { setView('list'); setSelected(null); };

  const flaggedCount = clients.filter(c => c.flagged).length;
  const displayed    = filterFlagged ? clients.filter(c => c.flagged) : clients;

  return (
    <div style={S.shell}>
      {/* ── Header ── */}
      <div style={S.header}>
        <div style={S.headerLeft}>
          {view !== 'list' && (
            <button onClick={goBack} style={S.backBtn}>← Back</button>
          )}
          <span style={S.logo}>EVOLVE<span style={S.logoOrange}>:</span>COACH</span>
        </div>
        {view === 'list' && (
          <div style={S.headerRight}>
            {flaggedCount > 0 && (
              <button
                style={{ ...S.filterBtn, ...(filterFlagged ? S.filterBtnActive : {}) }}
                onClick={() => setFilter(f => !f)}
              >
                🔴 {flaggedCount} flagged
              </button>
            )}
            <button onClick={loadClients} style={S.refreshBtn}>↻ Refresh</button>
          </div>
        )}
      </div>

      {/* ── Body ── */}
      <div style={S.body}>
        {loading && <LoadingState />}
        {error   && <ErrorState msg={error} onRetry={loadClients} />}
        {!loading && !error && (
          <>
            {view === 'list'    && <ClientList clients={displayed} onSelect={openClient} onTargets={openTargets} />}
            {view === 'detail'  && <ClientDetail clientId={selectedClient.clientId} name={selectedClient.name} onTargets={() => openTargets(selectedClient)} />}
            {view === 'targets' && <TargetEditor client={selectedClient} onSaved={goBack} onCancel={goBack} />}
          </>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// CLIENT LIST
// ─────────────────────────────────────────────────────────────────
function ClientList({ clients, onSelect, onTargets }) {
  if (!clients.length) {
    return (
      <div style={S.empty}>
        <p style={S.emptyText}>No active clients.</p>
        <p style={S.emptyHint}>Add clients by setting Active = TRUE in the Consultations sheet.</p>
      </div>
    );
  }

  return (
    <div style={S.cardGrid}>
      {clients.map(c => (
        <ClientCard key={c.clientId} client={c} onSelect={onSelect} onTargets={onTargets} />
      ))}
    </div>
  );
}

function ClientCard({ client, onSelect, onTargets }) {
  const { name, streak, lastLogDate, daysSinceLog, flagged } = client;

  const statusIcon  = flagged ? '🔴' : daysSinceLog === 0 ? '✅' : daysSinceLog === 1 ? '🟡' : '🟠';
  const statusLabel = flagged
    ? `No log for ${daysSinceLog} days`
    : daysSinceLog === 0 ? 'Logged today'
    : daysSinceLog === 1 ? 'Logged yesterday'
    : `${daysSinceLog} days ago`;

  return (
    <div style={{ ...S.card, ...(flagged ? S.cardFlagged : {}) }}>
      <div style={S.cardTop}>
        <span style={S.cardName}>{name}</span>
        <span style={S.statusBadge}>{statusIcon}</span>
      </div>
      <div style={S.cardMeta}>
        <span style={S.metaItem}>🔥 {streak} day streak</span>
        <span style={{ ...S.metaItem, ...(flagged ? S.metaFlagged : {}) }}>{statusLabel}</span>
      </div>
      <div style={S.cardActions}>
        <button style={S.btnPrimary} onClick={() => onSelect(client)}>View data</button>
        <button style={S.btnSecondary} onClick={() => onTargets(client)}>Targets</button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// CLIENT DETAIL
// ─────────────────────────────────────────────────────────────────
function ClientDetail({ clientId, name, onTargets }) {
  const [data, setData]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tab, setTab]     = useState('overview'); // 'overview' | 'logs' | 'checkins'

  useEffect(() => {
    (async () => {
      setLoading(true); setError(null);
      try {
        const d = await apiFetch({ action: 'getClientDashboard', clientId });
        setData(d);
      } catch(e) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    })();
  }, [clientId]);

  if (loading) return <LoadingState />;
  if (error)   return <ErrorState msg={error} />;

  const { logs, checkins, targets, streak, lastLogDate, daysSinceLog } = data;

  return (
    <div style={S.detailShell}>
      {/* Client header */}
      <div style={S.detailHeader}>
        <div>
          <h2 style={S.detailName}>{name}</h2>
          <p style={S.detailMeta}>
            🔥 {streak} day streak · Last log: {lastLogDate || 'never'} · {daysSinceLog === 0 ? 'Logged today' : `${daysSinceLog}d ago`}
          </p>
        </div>
        <button style={S.btnPrimary} onClick={onTargets}>Edit targets</button>
      </div>

      {/* Tabs */}
      <div style={S.tabs}>
        {['overview','logs','checkins'].map(t => (
          <button
            key={t}
            style={{ ...S.tab, ...(tab === t ? S.tabActive : {}) }}
            onClick={() => setTab(t)}
          >
            {t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      {/* Tab content */}
      {tab === 'overview'  && <OverviewTab logs={logs} targets={targets} />}
      {tab === 'logs'      && <LogsTab logs={logs} />}
      {tab === 'checkins'  && <CheckinsTab checkins={checkins} />}
    </div>
  );
}

// ── Overview: 30-day habit summary ───────────────────────────────
function OverviewTab({ logs, targets }) {
  // Build last-30-days calendar data
  const today = new Date();
  const days  = Array.from({ length: 30 }, (_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() - (29 - i));
    return d.toISOString().split('T')[0];
  });

  const logsByDate = {};
  logs.forEach(l => {
    // Handle both 'Date' (capitalised, from Apps Script) and 'date' (lowercase)
    const dateVal = l['Date'] || l['date'];
    if (dateVal) {
      const dateStr = typeof dateVal === 'string'
        ? dateVal.split('T')[0]
        : new Date(dateVal).toISOString().split('T')[0];
      logsByDate[dateStr] = l;
    }
  });

  return (
    <div>
      {/* 30-day mini calendar */}
      <h3 style={S.sectionTitle}>Last 30 days</h3>
      <div style={S.calGrid}>
        {days.map(d => {
          // Logs keyed by 'Date' column value (ISO string)
        const logged = !!logsByDate[d];
          return (
            <div
              key={d}
              title={d}
              style={{ ...S.calCell, backgroundColor: logged ? '#F26419' : '#2a3a4a' }}
            />
          );
        })}
      </div>

      {/* Habit averages */}
      <h3 style={S.sectionTitle}>Habit averages (last 30 days)</h3>
      <HabitAverages logs={logs} targets={targets} />
    </div>
  );
}

function HabitAverages({ logs, targets }) {
  // FIX: keys and units match client app COLUMNS array exactly
  const HABITS = [
    { key: 'Sleep (hrs)',       label: 'Sleep',       unit: 'hrs' },
    { key: 'Steps',             label: 'Steps',       unit: ''    },
    { key: 'Hydration (L)',     label: 'Hydration',   unit: 'L'   },
    { key: 'Meals',             label: 'Meals',       unit: ''    },
    { key: 'Mindfulness (min)', label: 'Mindfulness', unit: 'min' },
    { key: 'Mobility (min)',    label: 'Mobility',    unit: 'min' },
    { key: 'Stress RPE (1-10)', label: 'Stress',      unit: '/10' },
    { key: 'Mood (1-10)',       label: 'Mood',        unit: '/10' },
    { key: 'Energy (1-10)',     label: 'Energy',      unit: '/10' },
    { key: 'Digestion (1-10)',  label: 'Digestion',   unit: '/10' },
  ];

  const recent = logs.slice(-30);

  return (
    <div style={S.habitGrid}>
      {HABITS.map(({ key, label, unit }) => {
        const vals = recent.map(l => parseFloat(l[key])).filter(v => !isNaN(v));
        const avg  = vals.length ? (vals.reduce((a,b) => a+b, 0) / vals.length).toFixed(1) : '—';
        // Map column header key back to targets object key for reference line
        const TARGET_KEY_MAP = {
          'Sleep (hrs)': 'sleep', 'Steps': 'steps', 'Hydration (L)': 'hydration',
          'Meals': 'meals', 'Mindfulness (min)': 'mindfulness', 'Mobility (min)': 'mobility',
          'Stress RPE (1-10)': 'stress', 'Mood (1-10)': 'mood',
          'Energy (1-10)': 'energy', 'Digestion (1-10)': 'digestion',
        };
        const targetKey = TARGET_KEY_MAP[key];
        const target = targets?.[targetKey];
        const pct  = target && avg !== '—' ? Math.min(100, (parseFloat(avg) / parseFloat(target)) * 100) : null;

        return (
          <div key={key} style={S.habitCard}>
            <p style={S.habitLabel}>{label}</p>
            <p style={S.habitValue}>{avg}{avg !== '—' ? unit : ''}</p>
            {target && <p style={S.habitTarget}>Target: {target}{unit}</p>}
            {pct !== null && (
              <div style={S.progressBar}>
                <div style={{ ...S.progressFill, width: `${pct}%`, backgroundColor: pct >= 100 ? '#22c55e' : pct >= 70 ? '#F26419' : '#ef4444' }} />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

// ── Logs tab: raw log table ───────────────────────────────────────
function LogsTab({ logs }) {
  const sorted = [...logs].sort((a,b) => (b.date||'').localeCompare(a.date||''));
  if (!sorted.length) return <p style={S.emptyText}>No logs yet.</p>;

  const keys = Object.keys(sorted[0]).filter(k => k !== 'clientId');

  return (
    <div style={S.tableWrap}>
      <table style={S.table}>
        <thead>
          <tr>{keys.map(k => <th key={k} style={S.th}>{k}</th>)}</tr>
        </thead>
        <tbody>
          {sorted.map((row, i) => (
            <tr key={`${row.Date || row.date || ''}-${i}`}>
              {keys.map(k => <td key={k} style={S.td}>{String(row[k] ?? '')}</td>)}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Check-ins tab ─────────────────────────────────────────────────
function CheckinsTab({ checkins }) {
  const sorted = [...checkins].sort((a,b) => (b.date||'').localeCompare(a.date||''));
  if (!sorted.length) return <p style={S.emptyText}>No check-ins submitted yet.</p>;

  return (
    <div>
      {sorted.map((c, i) => (
        <div key={i} style={S.checkinCard}>
          <p style={S.checkinDate}>{c.date} · {c.type || 'check-in'}</p>
          {Object.entries(c)
            .filter(([k]) => !['clientId','date','type'].includes(k))
            .map(([k, v]) => (
              <p key={k} style={S.checkinRow}><strong>{k}:</strong> {String(v)}</p>
            ))
          }
        </div>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// TARGET EDITOR
// ─────────────────────────────────────────────────────────────────
function TargetEditor({ client, onSaved, onCancel }) {
  const [targets, setTargets] = useState({ ...client.targets });
  const [saving, setSaving]   = useState(false);
  const [error, setError]     = useState(null);

  // FIX: keys match client app DEFAULT_TARGETS exactly
  const TARGET_FIELDS = [
    { key: 'sleep',       label: 'Sleep target (hrs)',          type: 'number', step: '0.5' },
    { key: 'steps',       label: 'Step target',                 type: 'number', step: '500' },
    { key: 'hydration',   label: 'Daily hydration target (L)',  type: 'number', step: '0.25' },
    { key: 'meals',       label: 'Meal target (per day)',       type: 'number', step: '1'   },
    { key: 'mindfulness', label: 'Mindfulness target (min)',    type: 'number', step: '1'   },
    { key: 'mobility',    label: 'Mobility target (min)',       type: 'number', step: '5'   },
    { key: 'stress',      label: 'Stress baseline (1–10)',      type: 'number', step: '1'   },
    { key: 'mood',        label: 'Mood baseline (1–10)',        type: 'number', step: '1'   },
    { key: 'energy',      label: 'Energy baseline (1–10)',      type: 'number', step: '1'   },
    { key: 'digestion',   label: 'Digestion baseline (1–10)',   type: 'number', step: '1'   },
  ];

  const handleSave = async () => {
    setSaving(true); setError(null);
    try {
      await apiPost({ action: 'updateTargets', clientId: client.clientId, targets });
      onSaved();
    } catch(e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div style={S.editorShell}>
      <h2 style={S.detailName}>Targets — {client.name}</h2>
      <p style={S.detailMeta}>Changes take effect immediately on the client app.</p>

      <div style={S.fieldGrid}>
        {TARGET_FIELDS.map(({ key, label, type, step }) => (
          <div key={key} style={S.fieldGroup}>
            <label style={S.fieldLabel}>{label}</label>
            <input
              type={type}
              step={step}
              value={targets[key] ?? ''}
              onChange={e => setTargets(t => ({ ...t, [key]: e.target.value === '' ? '' : Number(e.target.value) }))}
              style={S.input}
            />
          </div>
        ))}
      </div>

      {error && <p style={S.errorMsg}>Save failed: {error}</p>}

      <div style={S.editorActions}>
        <button style={S.btnSecondary} onClick={onCancel} disabled={saving}>Cancel</button>
        <button style={S.btnPrimary}   onClick={handleSave} disabled={saving}>
          {saving ? 'Saving…' : 'Save targets'}
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// AUTH STATES
// ─────────────────────────────────────────────────────────────────
function PasswordGate({ onSuccess }) {
  const [input, setInput]   = useState('');
  const [error, setError]   = useState(false);

  const handleSubmit = () => {
    if (input === import.meta.env.VITE_COACH_SECRET) {
      onSuccess();
    } else {
      setError(true);
      setInput('');
      setTimeout(() => setError(false), 2000);
    }
  };

  return (
    <div style={S.authShell}>
      <span style={S.logo}>EVOLVE<span style={S.logoOrange}>:</span>COACH</span>
      <div style={S.gateBox}>
        <input
          type="password"
          placeholder="Coach password"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleSubmit()}
          style={{ ...S.input, width: '100%', boxSizing: 'border-box', ...(error ? { borderColor: '#ef4444' } : {}) }}
          autoFocus
        />
        {error && <p style={{ ...S.errorMsg, marginTop: '8px' }}>Incorrect password.</p>}
        <button style={{ ...S.btnPrimary, width: '100%', marginTop: '10px', padding: '12px' }} onClick={handleSubmit}>
          Enter
        </button>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// UTILITY COMPONENTS
// ─────────────────────────────────────────────────────────────────
function LoadingState() {
  return <p style={S.loadingText}>Loading…</p>;
}

function ErrorState({ msg, onRetry }) {
  return (
    <div style={S.errorShell}>
      <p style={S.errorMsg}>{msg}</p>
      {onRetry && <button style={S.btnSecondary} onClick={onRetry}>Retry</button>}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// STYLES — brand tokens: Navy #1C2B3A | Orange #F26419 | Cream #F0EEF5
// ─────────────────────────────────────────────────────────────────
const S = {
  shell:        { minHeight:'100vh', backgroundColor:'#0f1a24', color:'#F0EEF5', fontFamily:'Barlow, sans-serif' },
  header:       { display:'flex', justifyContent:'space-between', alignItems:'center', padding:'16px 20px', backgroundColor:'#1C2B3A', borderBottom:'2px solid #F26419' },
  headerLeft:   { display:'flex', alignItems:'center', gap:'12px' },
  headerRight:  { display:'flex', alignItems:'center', gap:'8px' },
  logo:         { fontFamily:'"Barlow Condensed", sans-serif', fontWeight:900, fontSize:'20px', letterSpacing:'0.05em', color:'#F0EEF5' },
  logoOrange:   { color:'#F26419' },
  body:         { padding:'20px', maxWidth:'900px', margin:'0 auto' },

  cardGrid:     { display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(260px,1fr))', gap:'16px' },
  card:         { backgroundColor:'#1C2B3A', borderRadius:'10px', padding:'16px', border:'1px solid #2a3a4a' },
  cardFlagged:  { borderColor:'#ef4444', boxShadow:'0 0 0 1px #ef444433' },
  cardTop:      { display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'8px' },
  cardName:     { fontFamily:'"Barlow Condensed", sans-serif', fontWeight:700, fontSize:'18px', textTransform:'uppercase' },
  statusBadge:  { fontSize:'20px' },
  cardMeta:     { display:'flex', flexDirection:'column', gap:'2px', marginBottom:'12px' },
  metaItem:     { fontSize:'13px', color:'#94a3b8' },
  metaFlagged:  { color:'#ef4444' },
  cardActions:  { display:'flex', gap:'8px' },

  btnPrimary:   { backgroundColor:'#F26419', color:'#fff', border:'none', borderRadius:'6px', padding:'8px 16px', fontFamily:'Barlow, sans-serif', fontWeight:600, fontSize:'13px', cursor:'pointer' },
  btnSecondary: { backgroundColor:'transparent', color:'#F0EEF5', border:'1px solid #3a4a5a', borderRadius:'6px', padding:'8px 16px', fontFamily:'Barlow, sans-serif', fontWeight:600, fontSize:'13px', cursor:'pointer' },
  backBtn:      { backgroundColor:'transparent', color:'#94a3b8', border:'none', cursor:'pointer', fontFamily:'Barlow, sans-serif', fontSize:'14px', padding:'4px 0' },
  filterBtn:    { backgroundColor:'transparent', color:'#94a3b8', border:'1px solid #3a4a5a', borderRadius:'6px', padding:'6px 12px', fontFamily:'Barlow, sans-serif', fontSize:'13px', cursor:'pointer' },
  filterBtnActive: { borderColor:'#ef4444', color:'#ef4444' },
  refreshBtn:   { backgroundColor:'transparent', color:'#94a3b8', border:'1px solid #3a4a5a', borderRadius:'6px', padding:'6px 12px', fontFamily:'Barlow, sans-serif', fontSize:'13px', cursor:'pointer' },

  detailShell:  { paddingBottom:'40px' },
  detailHeader: { display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:'20px' },
  detailName:   { fontFamily:'"Barlow Condensed", sans-serif', fontWeight:900, fontSize:'28px', textTransform:'uppercase', margin:'0 0 4px 0' },
  detailMeta:   { fontSize:'13px', color:'#94a3b8', margin:0 },

  tabs:         { display:'flex', gap:'4px', marginBottom:'20px', borderBottom:'1px solid #2a3a4a', paddingBottom:'0' },
  tab:          { backgroundColor:'transparent', color:'#94a3b8', border:'none', borderBottom:'2px solid transparent', padding:'8px 16px', fontFamily:'Barlow, sans-serif', fontWeight:600, fontSize:'14px', cursor:'pointer', marginBottom:'-1px' },
  tabActive:    { color:'#F26419', borderBottomColor:'#F26419' },

  sectionTitle: { fontFamily:'"Barlow Condensed", sans-serif', fontWeight:700, fontSize:'16px', textTransform:'uppercase', letterSpacing:'0.05em', color:'#94a3b8', margin:'20px 0 10px' },

  calGrid:      { display:'grid', gridTemplateColumns:'repeat(10,1fr)', gap:'4px', marginBottom:'8px' },
  calCell:      { height:'24px', borderRadius:'3px' },

  habitGrid:    { display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(160px,1fr))', gap:'12px' },
  habitCard:    { backgroundColor:'#1C2B3A', borderRadius:'8px', padding:'12px' },
  habitLabel:   { fontSize:'12px', color:'#94a3b8', margin:'0 0 4px' },
  habitValue:   { fontFamily:'"Barlow Condensed", sans-serif', fontWeight:700, fontSize:'24px', margin:'0 0 2px' },
  habitTarget:  { fontSize:'11px', color:'#64748b', margin:'0 0 6px' },
  progressBar:  { height:'4px', backgroundColor:'#2a3a4a', borderRadius:'2px', overflow:'hidden' },
  progressFill: { height:'100%', borderRadius:'2px', transition:'width 0.3s' },

  tableWrap:    { overflowX:'auto' },
  table:        { width:'100%', borderCollapse:'collapse', fontSize:'13px' },
  th:           { textAlign:'left', padding:'8px 12px', backgroundColor:'#1C2B3A', color:'#94a3b8', fontWeight:600, whiteSpace:'nowrap', borderBottom:'1px solid #2a3a4a' },
  td:           { padding:'8px 12px', borderBottom:'1px solid #1a2a3a', whiteSpace:'nowrap' },

  checkinCard:  { backgroundColor:'#1C2B3A', borderRadius:'8px', padding:'14px', marginBottom:'10px' },
  checkinDate:  { fontFamily:'"Barlow Condensed", sans-serif', fontWeight:700, fontSize:'15px', margin:'0 0 8px', color:'#F26419' },
  checkinRow:   { fontSize:'13px', margin:'2px 0', color:'#F0EEF5' },

  editorShell:  { maxWidth:'600px' },
  fieldGrid:    { display:'grid', gridTemplateColumns:'1fr 1fr', gap:'14px', margin:'20px 0' },
  fieldGroup:   { display:'flex', flexDirection:'column', gap:'4px' },
  fieldLabel:   { fontSize:'12px', color:'#94a3b8', fontWeight:600 },
  input:        { backgroundColor:'#1C2B3A', border:'1px solid #2a3a4a', borderRadius:'6px', padding:'8px 12px', color:'#F0EEF5', fontFamily:'Barlow, sans-serif', fontSize:'14px', outline:'none' },
  editorActions:{ display:'flex', gap:'10px', justifyContent:'flex-end', marginTop:'20px' },

  authShell:    { display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', minHeight:'60vh', gap:'16px' },
  authText:     { color:'#94a3b8', fontSize:'14px', textAlign:'center' },
  gateBox:      { width:'100%', maxWidth:'320px', display:'flex', flexDirection:'column' },

  empty:        { textAlign:'center', padding:'60px 20px' },
  emptyText:    { color:'#94a3b8', fontSize:'16px', margin:'0 0 8px' },
  emptyHint:    { color:'#64748b', fontSize:'13px', margin:0 },
  loadingText:  { color:'#94a3b8', textAlign:'center', padding:'60px', fontSize:'16px' },
  errorShell:   { textAlign:'center', padding:'40px 20px' },
  errorMsg:     { color:'#ef4444', fontSize:'14px', margin:'0 0 12px' },
};
